import '../../domain/entities/article.dart';
import '../models/article_dto.dart';


class ArticleMapper {
  static Article fromDto(ArticleDto dto) {
    // Use URL as unique ID fallback
    final id = dto.url;
    DateTime? published;
    if (dto.publishedAt != null) {
      try { published = DateTime.parse(dto.publishedAt!); } catch (_) {}
    }
    return Article(
      id: id,
      title: dto.title,
      imageUrl: dto.urlToImage,
      publishedAt: published,
      content: dto.content,
      description: dto.description,
      url: dto.url,
    );
  }
}