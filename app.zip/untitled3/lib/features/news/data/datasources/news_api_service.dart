import 'package:dio/dio.dart';
import 'dart:convert';

class NewsApiService {
  final Dio _dio;
  final String baseUrl;
  final String apiKey;

  NewsApiService(this._dio, {required this.baseUrl, required this.apiKey});

  /// Fetch top headlines. On error this returns a Map with `status: 'error'`
  /// and a `message` (and sometimes `code`) instead of throwing.
  Future<Map<String, dynamic>> getTopHeadlines({
    String country = 'us',
    int page = 1,
  }) async {
    try {
      final response = await _dio.get(
        '$baseUrl/top-headlines',
        queryParameters: {
          'country': country,
          'page': page,
          'pageSize': 20,
          'apiKey': apiKey,
        },
        options: Options(
          // small timeout so the app doesn't hang
          receiveTimeout: const Duration(seconds: 5),
          sendTimeout: const Duration(seconds: 5),
        ),
      );

      final data = response.data;

      // If API returns a Map (normal case), return it unchanged
      if (data is Map<String, dynamic>) {
        return data;
      }

      // Sometimes response.data is JSON string — try to decode
      if (data is String) {
        try {
          final decoded = json.decode(data);
          if (decoded is Map<String, dynamic>) return decoded;
        } catch (_) {
          // ignore decode error, fallthrough to error return below
        }
      }

      // Unexpected format: return an error-shaped map to avoid breaking callers.
      return {
        'status': 'error',
        'message': 'Unexpected response format from server',
        'raw': data?.toString(),
      };
    } catch (e, st) {
      // Print full debug info to console (useful when debugging 401)
      print('NewsApiService.getTopHeadlines failed: $e\n$st');

      // Try to extract response details if available (works for Dio exceptions)
      try {
        final resp = (e as dynamic).response;
        if (resp != null) {
          return {
            'status': 'error',
            'code': resp.statusCode,
            // resp.data might be a Map or String; include as-is for debugging
            'message': resp.data ?? resp.statusMessage ?? e.toString(),
          };
        }
      } catch (_) {
        // ignore extraction errors
      }

      // Generic fallback error map
      return {
        'status': 'error',
        'message': e.toString(),
      };
    }
  }
}