import 'package:untitled3/core/failure.dart';
import '../../domain/entities/article.dart';
import '../../domain/repositories/article_repository.dart';
import '../datasources/news_api_service.dart';
import '../models/article_dto.dart';
import '../mappers/article_mapper.dart';

class ArticleRepositoryImpl implements ArticleRepository {
  final NewsApiService api;

  ArticleRepositoryImpl(this.api);

  @override
  Future<List<Article>> getTopHeadlines({String country = 'us', int page = 1}) async {
    try {
      final data = await api.getTopHeadlines(country: country, page: page);
      if (data['status'] != 'ok') {
        throw Failure('API error: ${data['message'] ?? 'unknown'}');
      }
      final List<dynamic> articlesJson = (data['articles'] ?? []) as List<dynamic>;
      final dtos = articlesJson.map((e) => ArticleDto.fromJson(e as Map<String, dynamic>)).toList();
      final entities = dtos.map(ArticleMapper.fromDto).toList();
      return entities;
    } catch (e) {
      throw Failure(e.toString());
    }
  }
}