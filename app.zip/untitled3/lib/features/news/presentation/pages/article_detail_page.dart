import 'package:flutter/material.dart';
import '../../domain/entities/article.dart';
import 'package:intl/intl.dart';

class ArticleDetailPage extends StatelessWidget {
  final Article article;
  const ArticleDetailPage({super.key, required this.article});

  @override
  Widget build(BuildContext context) {
    final date = article.publishedAt != null ? DateFormat.yMMMMd().add_jm().format(article.publishedAt!.toLocal()) : null;
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (article.imageUrl != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(article.imageUrl!, fit: BoxFit.cover,
                loadingBuilder: (c, w, p) => p == null ? w : const SizedBox(height: 200, child: Center(child: CircularProgressIndicator())),
                errorBuilder: (_, __, ___) => const SizedBox(height: 200, child: Center(child: Icon(Icons.broken_image))),
              ),
            ),
          const SizedBox(height: 12),
          Text(article.title, style: Theme.of(context).textTheme.titleLarge),
          if (date != null) ...[
            const SizedBox(height: 4),
            Text(date, style: Theme.of(context).textTheme.bodySmall),
          ],
          const SizedBox(height: 12),
          if ((article.content ?? '').isNotEmpty)
            Text(article.content!)
          else if ((article.description ?? '').isNotEmpty)
            Text(article.description!)
          else
            const Text('No content provided. Tap the link below to read more.'),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () async {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Use url_launcher to open original URL.')));
            },
            child: Text(article.url),
          ),
        ],
      ),
    );
  }
}