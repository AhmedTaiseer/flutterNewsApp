import 'package:dio/dio.dart';
import '../features/news/data/datasources/news_api_service.dart';

final sl = <Type, dynamic>{};

Future<void> init() async {
  const String baseUrl = 'https://newsapi.org/v2';
  const String apiKey = '53c3a36d4b5b45ed9f7667ebd159279f'; // put your actual key here

  // Store singletons manually (no GetIt)
  sl[Dio] = Dio();
  sl[NewsApiService] = NewsApiService(
    sl[Dio] as Dio,
    baseUrl: baseUrl,
    apiKey: apiKey,
  );
}

T getIt<T>() => sl[T] as T;